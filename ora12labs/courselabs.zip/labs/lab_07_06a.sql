CREATE TABLE card_table
(accepted_cards VARCHAR2(50) NOT NULL);
