@$HOME/labs/lab_08_01.sql
