CREATE OR REPLACE LIBRARY c_code AS '$ORACLE_HOME/bin/calc_tax.so';
