EXECUTE credit_card_pkg.update_card_info(120, 'AM EX',55555555555)
 
EXECUTE credit_card_pkg.display_card_info(120)
