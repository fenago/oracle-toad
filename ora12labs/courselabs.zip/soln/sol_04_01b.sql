cp calc_tax.so $ORACLE_HOME/bin
