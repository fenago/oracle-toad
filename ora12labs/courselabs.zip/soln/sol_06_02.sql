CONNECT /AS sysdba

CREATE CONTEXT sales_orders_ctx
USING oe.sales_orders_pkg;
