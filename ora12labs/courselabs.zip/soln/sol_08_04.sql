SET SERVEROUTPUT ON

EXECUTE my_profiler('Benchmark Run.' , 'This is the first run.')
