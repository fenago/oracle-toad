EXECUTE add_project(10, -
            typ_Project(4, 'Information Technology', 789), 4)

SELECT * FROM department;
