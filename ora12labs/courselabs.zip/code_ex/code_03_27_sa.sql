SELECT * FROM department;
