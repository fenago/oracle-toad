EXECUTE dbms_output.put_line(get_credit(101))
