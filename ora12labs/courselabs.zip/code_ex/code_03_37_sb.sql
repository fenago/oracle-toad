EXECUTE report_credit('Walken', 1200)
