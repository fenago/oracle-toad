CONNECT AM148/oracle

SELECT   customer_id, cust_last_name
FROM     oe.customers;
