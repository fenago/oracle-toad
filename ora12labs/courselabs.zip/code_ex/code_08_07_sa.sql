SET SERVEROUT ON
EXECUTE query_code_pkg.encap_compliance
