SELECT notice MULTISET INTERSECT payments
FROM Porder ;
