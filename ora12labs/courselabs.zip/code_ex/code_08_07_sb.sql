EXECUTE query_code_pkg.find_text_in_code('customers')
