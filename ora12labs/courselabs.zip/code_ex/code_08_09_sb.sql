-- you need to run code_08_10_na prior to executing this next command.


EXEC use_dbms_describe.get_data('ORDERS_APP_PKG.THE_PREDICATE')
