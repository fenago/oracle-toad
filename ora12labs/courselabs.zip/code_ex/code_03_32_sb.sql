SELECT  ordid
FROM    pOrder
WHERE   notice = payments;
