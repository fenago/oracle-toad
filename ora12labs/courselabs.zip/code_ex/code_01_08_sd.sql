SELECT get_credit(customer_id) FROM customers;
