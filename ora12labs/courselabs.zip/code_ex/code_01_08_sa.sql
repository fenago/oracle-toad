VARIABLE v_credit NUMBER
EXECUTE :v_credit := get_credit(101)
