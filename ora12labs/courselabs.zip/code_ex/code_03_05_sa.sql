DESCRIBE customers
