SELECT customer_id, cust_first_name, cust_last_name, cust_address
FROM   customers
WHERE  customer_id = 1000;
