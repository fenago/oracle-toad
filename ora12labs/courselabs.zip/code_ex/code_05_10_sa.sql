SELECT text
FROM user_source
WHERE name = 'SHOW_TABLE';