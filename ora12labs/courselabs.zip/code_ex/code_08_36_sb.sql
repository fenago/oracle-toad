SELECT line#, total_occur, total_time, min_time, max_time
FROM   plsql_profiler_data
WHERE  runid = 1 AND unit_number = 2;
