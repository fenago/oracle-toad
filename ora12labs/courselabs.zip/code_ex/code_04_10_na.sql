CREATE OR REPLACE LIBRARY c_utility
AS '$ORACLE_HOME/bin/calc_tax.so';
/