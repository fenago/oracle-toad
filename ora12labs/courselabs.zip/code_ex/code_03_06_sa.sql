INSERT INTO CUSTOMERS (customer_id, cust_first_name, 
                       cust_last_name, cust_address)
VALUES (1000, 'John', 'Smith', 
  cust_address_typ ( '285 Derby Street'
                  , '02465'                  
                  , 'Boston'
                  , 'MA'
                  , 'US'));
