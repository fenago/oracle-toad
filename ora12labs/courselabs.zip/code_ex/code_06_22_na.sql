SELECT object_name, policy_name, pf_owner, package, function,
       sel, ins, upd, del
FROM all_policies;
