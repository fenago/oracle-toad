CONNECT /AS sysdba

CREATE CONTEXT order_ctx USING oe.orders_app_pkg;

CONNECT oe/oe
