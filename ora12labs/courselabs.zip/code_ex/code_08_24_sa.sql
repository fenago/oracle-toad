ALTER SESSION SET PLSQL_DEBUG=true;

-- now recompile the procedures created on page 18:

@code_08_18_na.sql
