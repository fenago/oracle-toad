CONNECT AM148/oracle

UPDATE oe.customers
SET credit_limit = credit_limit + 5000
WHERE customer_id = 101;
