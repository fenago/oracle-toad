CONNECT AM148/oracle

SELECT * 
FROM   all_context;

CONNECT oe/oe
