EXECUTE top_with_logging
