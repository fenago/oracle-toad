create cluster org_staff_clus (deptno number(4))
/
