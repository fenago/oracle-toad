CREATE TABLE ITEM  (
 ORDID               NUMBER (4) NOT NULL,
 ITEMID              NUMBER (4) NOT NULL,
 PRODID              NUMBER (6),
 ACTUALPRICE         NUMBER (8,2),
 QTY                 NUMBER (8),
 ITEMTOT             NUMBER (8,2))
/
