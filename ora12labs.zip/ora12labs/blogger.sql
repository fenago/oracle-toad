create user blogger identified by blogger
       default tablespace tools
       temporary tablespace temp
/
