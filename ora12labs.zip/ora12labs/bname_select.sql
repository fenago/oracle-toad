set heading off
set feedback off
set termout off
select bname from bigpart
            where bname like 'BET%';
set termout on
set feedback on
set heading on


