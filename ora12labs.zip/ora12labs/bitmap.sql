CREATE BITMAP INDEX big_bname
ON  big (bname) 
TABLESPACE example
/
