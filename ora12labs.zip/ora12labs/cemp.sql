select loc,dname,ename,sal from
         dept join emp
         on dept.deptno = emp.deptno
/
