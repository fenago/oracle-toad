create directory dpump as 'c:\oracle\'
/
