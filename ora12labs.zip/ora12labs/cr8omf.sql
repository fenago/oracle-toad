create tablespace OMF20m
            datafile size 20m
/
