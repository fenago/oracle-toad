ALTER TABLE av_data
       ADD CONSTRAINT av_primary_key 
         PRIMARY KEY (blob_id)
/
