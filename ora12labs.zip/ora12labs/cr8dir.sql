Create directory dmpdir1 as '/u01/app/oracle/product/10.2.0/db_1/dbs';
Grant read, write on directory dmpdir1 to scott;

/
