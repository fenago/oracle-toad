select username,expiry_date from dba_users

/
