SELECT USER,TO_CHAR(SYSDATE,'fmddth "of" Month, YYYY') Todays_Date FROM DUAL
/
