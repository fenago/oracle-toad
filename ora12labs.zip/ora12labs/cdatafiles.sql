select name from v$datafile
/
