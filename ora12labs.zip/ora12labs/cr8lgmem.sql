alter database add logfile member 'c:\oracle\redo1a.log' to group 1
/
