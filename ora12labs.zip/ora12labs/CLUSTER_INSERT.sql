insert into staff
         values (305,'RICHARD',10,'MGR',1,50000.00,5000.00)
/
