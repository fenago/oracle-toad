select file_name,tablespace_name
from dba_data_files
/
