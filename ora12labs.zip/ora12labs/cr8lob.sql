 CREATE TABLE TEST_LOB
 (id     number(15),
  clob_field   CLOB,
  blob_field   BLOB,
  bfile_field  BFILE)
  TABLESPACE USERS
/
