create table sergeant
              (ssn_sm     number(9) not null,
               name_ind   varchar2(27),
               gr_abbr_code varchar2(4) )
/
