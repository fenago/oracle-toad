select tablespace_name, status
       from dba_tablespaces
/
