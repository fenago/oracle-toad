REM  Script:  create_tables.sql
REM  Created: By Chaitanya Koratamaddi on 02/05/06
REM  This script creates tables for users ora1-40
--This script invokes hr_main
set echo on
spool ora1.log
connect ora1/ora1 
set echo off
@@hr_main.sql
spool off

set echo on
spool ora2.log
connect ora2/ora2 
set echo off
@@hr_main.sql
spool off

set echo on
spool ora3.log
connect ora3/ora3 
set echo off
@@hr_main.sql
spool off

set echo on
spool ora4.log
connect ora4/ora4 
set echo off
@@hr_main.sql
spool off

set echo on
spool ora5.log
connect ora5/ora5 
set echo off
@@hr_main.sql
spool off

set echo on
spool ora6.log
connect ora6/ora6 
set echo off
@@hr_main.sql
spool off

set echo on
spool ora7.log
connect ora7/ora7 
set echo off
@@hr_main.sql
spool off

set echo on
spool ora8.log
connect ora8/ora8 
set echo off
@@hr_main.sql
spool off

set echo on
spool ora9.log
connect ora9/ora9 
set echo off
@@hr_main.sql
spool off

set echo on
spool ora10.log
connect ora10/ora10 
set echo off
@@hr_main.sql
spool off

set echo on
spool ora11.log
connect ora11/ora11 
set echo off
@@hr_main.sql
spool off

set echo on
spool ora12.log
connect ora12/ora12 
set echo off
@@hr_main.sql
spool off

set echo on
spool ora13.log
connect ora13/ora13 
set echo off
@@hr_main.sql
spool off

set echo on
spool ora14.log
connect ora14/ora14 
set echo off
@@hr_main.sql
spool off

set echo on
spool ora15.log
connect ora15/ora15 
set echo off
@@hr_main.sql
spool off

set echo on
spool ora16.log
connect ora16/ora16 
set echo off
@@hr_main.sql
spool off

set echo on
spool ora17.log
connect ora17/ora17 
set echo off
@@hr_main.sql
spool off

set echo on
spool ora18.log
connect ora18/ora18 
set echo off
@@hr_main.sql
spool off

set echo on
spool ora19.log
connect ora19/ora19 
set echo off
@@hr_main.sql
spool off

set echo on
spool ora20.log
connect ora20/ora20
set echo off
@@hr_main.sql
spool off
   
set echo on
spool ora21.log
connect ora21/ora21 
set echo off
@@hr_main.sql
spool off

set echo on
spool ora22.log
connect ora22/ora22 
set echo off
@@hr_main.sql
spool off

set echo on
spool ora23.log
connect ora23/ora23 
set echo off
@@hr_main.sql
spool off

set echo on
spool ora4.log
connect ora24/ora24 
set echo off
@@hr_main.sql
spool off

set echo on
spool ora25.log
connect ora25/ora25 
set echo off
@@hr_main.sql
spool off

set echo on
spool ora26.log
connect ora26/ora26 
set echo off
@@hr_main.sql
spool off

set echo on
spool ora27.log
connect ora27/ora27 
set echo off
@@hr_main.sql
spool off

set echo on
spool ora28.log
connect ora28/ora28 
set echo off
@@hr_main.sql
spool off

set echo on
spool ora29.log
connect ora29/ora29 
set echo off
@@hr_main.sql
spool off

set echo on
spool ora30.log
connect ora30/ora30 
set echo off
@@hr_main.sql
spool off

set echo on
spool ora31.log
connect ora31/ora31 
set echo off
@@hr_main.sql
spool off

set echo on
spool ora32.log
connect ora32/ora32 
set echo off
@@hr_main.sql
spool off

set echo on
spool ora33.log
connect ora33/ora33 
set echo off
@@hr_main.sql
spool off

set echo on
spool ora34.log
connect ora34/ora34 
set echo off
@@hr_main.sql
spool off

set echo on
spool ora35.log
connect ora35/ora35 
set echo off
@@hr_main.sql
spool off

set echo on
spool ora36.log
connect ora36/ora36 
set echo off
@@hr_main.sql
spool off

set echo on
spool ora37.log
connect ora37/ora37 
set echo off
@@hr_main.sql
spool off

set echo on
spool ora38.log
connect ora38/ora38 
set echo off
@@hr_main.sql
spool off

set echo on
spool ora39.log
connect ora39/ora39 
set echo off
@@hr_main.sql
spool off

set echo on
spool ora40.log
connect ora40/ora40
set echo off
@@hr_main.sql
spool off

