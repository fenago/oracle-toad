alter tablespace users
          add datafile '/u01/app/oracle/oradata/orcl/users02.dbf' size 10m
/
