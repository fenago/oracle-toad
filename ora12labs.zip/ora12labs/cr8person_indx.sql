create index person_name_states_ind
              on person_tbl (name_ind,states_us)
/
