select name,value from v$parameter where name like lower('db_%')
/
