select bname from scott.big
            where bname like 'BET%'
/
