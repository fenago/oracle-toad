create user dba1 identified by password;
grant connect, dba, sysdba to dba1;