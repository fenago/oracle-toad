grant read,write on directory dpump to scott
/
