select * from staff
where salary <= 15000.00
/
