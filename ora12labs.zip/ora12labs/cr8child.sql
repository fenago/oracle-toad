create table child
         (n1    number,
          n2    number)
/
