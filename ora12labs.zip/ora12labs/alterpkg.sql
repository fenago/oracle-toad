alter package pkgxxx compile package
/
