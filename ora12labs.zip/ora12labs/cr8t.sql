CREATE TABLE t
(c    number,
 C1     number)
/
