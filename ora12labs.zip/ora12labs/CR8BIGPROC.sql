CREATE TABLE BIGPROC
            (BIGNO    NUMBER,
             BNAME    VARCHAR2(30))
/
