select 'insert into svcmbr_history values '||'('||mpc||','||asg_seq_nbr||','||
        pay_gr||','||state_tax_code||','||add_wh_tax||','||nbr_exempt||','||
        PEBD||','||tng_pay_ret_cat||','||
benef_stat_wvr_code||','||days_wvd||','||date_end_duty_deers_elig||','||
sgli_elect||','||sbp_opt||','||sbp_elect_cov||','||sbp_elect_stat||','||date_sbp_elect_stat||','||
curr_aero_rt||','||avn_svc_entry_date||','||tfos_date||','||curr_incent_term_stat||
','||date_curr_incent_term_stat||','||ipay_nbr_one||','||date_ipay_nbr_one||','||
ipay_nbr_two||','||date_ipay_nbr_two||','||sp_pay||','||pro_pay_stat||','||
pro_pay_date||','||date_start_duty_deers_elig||','||start_date||','||
end_date||','||ssn_sm||','||rec_prec||')'||';'
from svcmbr_history

/
