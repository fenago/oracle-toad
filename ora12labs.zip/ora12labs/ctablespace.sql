select tablespace_name,block_size,extent_management,status
       from dba_tablespaces
/
